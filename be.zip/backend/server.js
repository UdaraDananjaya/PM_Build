const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');  // Import cors
require('dotenv').config();


// Initialize Express app
const app = express();
const server = http.createServer(app);
app.use(cors());

// Create WebSocket server
const wss = new WebSocket.Server({ server });

// Store connected clients by roomId
const rooms = {};

// SQLite setup
const db = new sqlite3.Database('./ice_servers.db');

// Create the table for storing ICE servers (if it doesn't exist)
db.run('CREATE TABLE IF NOT EXISTS ice_servers (id INTEGER PRIMARY KEY, server_details TEXT)');

// Define your Twilio credentials (load them from environment variables)
const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID;
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN;
const TWILIO_API_URL = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Tokens.json`;

// Fetch ICE servers from Twilio API
async function fetchIceServers() {
    try {
        console.log("Fetching ICE servers from Twilio...");

        // Making the API request using axios
        const response = await axios.post(TWILIO_API_URL, {}, {
            auth: {
                username: TWILIO_ACCOUNT_SID,
                password: TWILIO_AUTH_TOKEN,
            },
            httpsAgent: new (require('https').Agent)({ rejectUnauthorized: false }) // Optional, if you need to ignore SSL verification
        });

        // Extract ICE servers from the response
        const iceServers = response.data.ice_servers;
        console.log("ICE Servers fetched:", iceServers);

        // Save the ICE servers data to SQLite
        db.run('INSERT INTO ice_servers (server_details) VALUES (?)', [JSON.stringify(iceServers)], (err) => {
            if (err) {
                console.error("Error saving ICE servers to DB:", err);
            } else {
                console.log("ICE servers saved to database.");
            }
        });
        
    } catch (error) {
        console.error("Error fetching ICE servers:", error);
    }
}

// Expose a GET endpoint to trigger the ICE servers update
app.get('/update-ice-servers', async (req, res) => {
    try {
        // Fetch and update ICE servers
        await fetchIceServers();

        // Respond to the client
        res.json({ message: 'ICE servers updated successfully.' });
    } catch (error) {
        res.status(500).json({ message: 'Error updating ICE servers.', error });
    }
});

// Expose a GET endpoint to get the latest ICE servers from DB
app.get('/test', (req, res) => {
            res.status(200).json({ message: 'No ICE servers found in the database.' });

});


// Expose a GET endpoint to get the latest ICE servers from DB
app.get('/get-ice-servers', (req, res) => {
    db.get('SELECT * FROM ice_servers ORDER BY id DESC LIMIT 1', (err, row) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching ICE servers from database.' });
        }

        if (row) {
            res.json(JSON.parse(row.server_details));
        } else {
            res.status(404).json({ message: 'No ICE servers found in the database.' });
        }
    });
});

// WebSocket server connection logic
wss.on('connection', (ws) => {
    console.log('New client connected');
  
    // When the client sends a message
    ws.on('message', (message) => {
        const parsedMessage = JSON.parse(message);

        switch (parsedMessage.type) {
            case 'join':
                // Handle joining a room
                handleJoin(ws, parsedMessage);
                break;

            case 'offer':
                // Handle offer
                handleOffer(ws, parsedMessage);
                break;

            case 'answer':
                // Handle answer
                handleAnswer(ws, parsedMessage);
                break;

            case 'ice-candidate':
                // Handle ICE candidate
                handleIceCandidate(ws, parsedMessage);
                break;

            default:
                break;
        }
    });

    ws.on('close', () => {
        console.log('Client disconnected');
        handleClientDisconnect(ws);
    });
});

// WebRTC Signaling Logic (handling WebSocket messages)
function handleJoin(ws, message) {
    const { roomId } = message;
    if (!rooms[roomId]) {
        rooms[roomId] = [];
    }
    rooms[roomId].push(ws);
    console.log(`Client joined room: ${roomId}`);
}

function handleOffer(ws, message) {
    const { roomId, offer } = message;
    rooms[roomId].forEach((client) => {
        if (client !== ws) {
            client.send(JSON.stringify({
                type: 'offer',
                offer: offer,
                roomId: roomId,
            }));
        }
    });
}

function handleAnswer(ws, message) {
    const { roomId, answer } = message;
    rooms[roomId].forEach((client) => {
        if (client !== ws) {
            client.send(JSON.stringify({
                type: 'answer',
                answer: answer,
                roomId: roomId,
            }));
        }
    });
}

function handleIceCandidate(ws, message) {
    const { roomId, candidate } = message;
    rooms[roomId].forEach((client) => {
        if (client !== ws) {
            client.send(JSON.stringify({
                type: 'ice-candidate',
                candidate: candidate,
                roomId: roomId,
            }));
        }
    });
}

// Handle client disconnection
function handleClientDisconnect(ws) {
    for (const roomId in rooms) {
        rooms[roomId] = rooms[roomId].filter(client => client !== ws);
        if (rooms[roomId].length === 0) {
            delete rooms[roomId]; // Clean up empty rooms
        }
    }
}

// Start server
server.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
