<template>
  <div>
    <div class="video-container">
      <video ref="localVideo" autoplay muted></video>
      <video ref="remoteVideo" autoplay></video>
    </div>
    <button @click="startCall">Start Call</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      localStream: null,
      peerConnection: null,
      socket: null,
      roomId: 'room-123', // Static room ID for now
      iceServers: [],
    };
  },
  mounted() {
    this.initWebSocket();
    this.getLocalStream();
    this.fetchIceServers();
  },
  methods: {
    // Initialize WebSocket connection to backend
    initWebSocket() {
      this.socket = new WebSocket('wss://vbackend.tendy.eu.org'); // WebSocket server URL

      this.socket.onopen = () => {
        console.log('Connected to WebSocket');
        this.socket.send(JSON.stringify({ type: 'join', roomId: this.roomId }));
      };

      this.socket.onmessage = (event) => {
        const message = JSON.parse(event.data);
        switch (message.type) {
          case 'offer':
            this.handleOffer(message);
            break;
          case 'answer':
            this.handleAnswer(message);
            break;
          case 'ice-candidate':
            this.handleIceCandidate(message);
            break;
          default:
            break;
        }
      };

      this.socket.onclose = () => {
        console.log('WebSocket connection closed');
      };

      this.socket.onerror = (error) => {
        console.error('WebSocket error:', error);
      };
    },

    // Fetch ICE servers from backend API
    async fetchIceServers() {
      try {
        const response = await fetch('https://vbackend.tendy.eu.org/get-ice-servers');
        const data = await response.json();
        this.iceServers = data;
      } catch (error) {
        console.error('Error fetching ICE servers:', error);
      }
    },

    // Get local video stream from webcam
    async getLocalStream() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        this.localStream = stream;
        this.$refs.localVideo.srcObject = stream;
      } catch (error) {
        console.error('Error accessing media devices.', error);
      }
    },

    // Start the WebRTC call
    startCall() {
      const configuration = {
        iceServers: this.iceServers, // Pass the ICE servers from the backend
		iceTransportPolicy: 'relay'
      };
      this.peerConnection = new RTCPeerConnection(configuration);

      // Add the local stream to the connection
      this.localStream.getTracks().forEach((track) => {
        this.peerConnection.addTrack(track, this.localStream);
      });

      this.peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
          this.socket.send(
            JSON.stringify({
              type: 'ice-candidate',
              candidate: event.candidate,
              roomId: this.roomId,
            })
          );
        }
      };

      // Listen for remote tracks
      this.peerConnection.ontrack = (event) => {
        console.log('Remote stream received');
        this.$refs.remoteVideo.srcObject = event.streams[0]; // Assign remote stream to remote video element
      };

      // Create an offer to send to the remote peer
      this.peerConnection
        .createOffer()
        .then((offer) => {
          return this.peerConnection.setLocalDescription(offer);
        })
        .then(() => {
          this.socket.send(
            JSON.stringify({
              type: 'offer',
              roomId: this.roomId,
              offer: this.peerConnection.localDescription,
            })
          );
        })
        .catch((error) => {
          console.error('Error creating offer:', error);
        });
    },

    // Handle the offer received from another peer
    handleOffer(message) {
      this.peerConnection = new RTCPeerConnection({
        iceServers: this.iceServers,
      });

      this.peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
          this.socket.send(
            JSON.stringify({
              type: 'ice-candidate',
              candidate: event.candidate,
              roomId: this.roomId,
            })
          );
        }
      };

      // When a remote stream is added, set it to the remote video
      this.peerConnection.ontrack = (event) => {
        console.log('Remote stream received');
        this.$refs.remoteVideo.srcObject = event.streams[0]; // Assign remote stream to remote video element
      };

      // Set the remote description and create an answer
      this.peerConnection
        .setRemoteDescription(new RTCSessionDescription(message.offer))
        .then(() => {
          return this.peerConnection.createAnswer();
        })
        .then((answer) => {
          return this.peerConnection.setLocalDescription(answer);
        })
        .then(() => {
          this.socket.send(
            JSON.stringify({
              type: 'answer',
              roomId: this.roomId,
              answer: this.peerConnection.localDescription,
            })
          );
        })
        .catch((error) => {
          console.error('Error handling offer:', error);
        });
    },

    // Handle the answer received from the other peer
    handleAnswer(message) {
      this.peerConnection.setRemoteDescription(new RTCSessionDescription(message.answer)).catch((error) => {
        console.error('Error setting remote description:', error);
      });
    },

    // Handle the ICE candidate received from the other peer
    handleIceCandidate(message) {
      const candidate = new RTCIceCandidate(message.candidate);
      this.peerConnection.addIceCandidate(candidate).catch((error) => {
        console.error('Error adding ICE candidate:', error);
      });
    },
  },
};
</script>

<style scoped>
.video-container {
  display: flex;
  justify-content: space-around;
  margin-top: 20px;
}

video {
  width: 45%;
  border: 2px solid black;
}
</style>
